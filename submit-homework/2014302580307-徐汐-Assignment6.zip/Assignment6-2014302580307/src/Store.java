import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class Store extends JFrame {

	private JPanel contentPane;


	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public Store() throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");
		Connection conn=null;
		Statement pstm;
		ResultSet rs = null;
		Connection conn2=null;
		Statement pstm2;
		ResultSet rs2;
		String url = "jdbc:mysql://localhost:3306/javademo?"+ "user=root&password=123456&useUnicode=true&characterEncoding=UTF8";
		conn2 = DriverManager.getConnection(url);
		pstm2 = conn2.createStatement();
		String sql2="select * from pets";
		rs2 = pstm2.executeQuery(sql2);
		
		ArrayList pets = new ArrayList();
		for (int n=1;n<4;n++){
			while(rs2.next()){
				Pet pet =new Pet();
				pet.id=rs2.getInt(n);
				pet.name = rs2.getString(n+1);
				pet.drink = rs2.getString(n+2);
				pet.eat = rs2.getString(n+3);
				pet.live = rs2.getString(n+4);
				pet.hobby=rs2.getString(n+5);
				pets.add(pet);
			}
		}
		setTitle("\u5546\u5E97");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 635, 451);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("\u8D2D\u7269\u8F66");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Car car=new Car();
				car.setVisible(true);
			}
		});
		button.setBounds(504, -1, 113, 27);
		contentPane.add(button);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(36, 56, 120, 143);
		contentPane.add(textArea);
		Pet pet=new Pet();
		pet=(Pet) pets.get(0);
		String a = pet.name;
		textArea.setText(pet.name+"\r\n"+pet.drink+"\r\n"+pet.eat+"\r\n"+pet.live+"\r\n"+pet.hobby);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBounds(182, 56, 120, 143);
		contentPane.add(textArea_1);
		Pet pet1=new Pet();
		pet1=(Pet) pets.get(1);
		String a1 = pet1.name;
		textArea_1.setText(pet1.name+"\r\n"+pet1.drink+"\r\n"+pet1.eat+"\r\n"+pet1.live+"\r\n"+pet1.hobby);
		
		JTextArea textArea_2 = new JTextArea();
		textArea_2.setBounds(327, 56, 120, 143);
		contentPane.add(textArea_2);
		Pet pet2=new Pet();
		pet2=(Pet) pets.get(2);
		String a2 = pet2.name;
		textArea_2.setText(pet2.name+"\r\n"+pet2.drink+"\r\n"+pet2.eat+"\r\n"+pet2.live+"\r\n"+pet2.hobby);
		
		JTextArea textArea_3 = new JTextArea();
		textArea_3.setBounds(470, 56, 120, 143);
		contentPane.add(textArea_3);
		Pet pet3=new Pet();
		pet3=(Pet) pets.get(3);
		String a3 = pet3.name;
		textArea_3.setText(pet3.name+"\r\n"+pet3.drink+"\r\n"+pet3.eat+"\r\n"+pet3.live+"\r\n"+pet3.hobby);
		
		JButton button_1 = new JButton("\u52A0\u5165\u8D2D\u7269\u8F66");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Carthings.goods.add(a);
			}
		});
		button_1.setBounds(36, 222, 113, 27);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("\u52A0\u5165\u8D2D\u7269\u8F66");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Carthings.goods.add(a1);
			}
		});
		button_2.setBounds(189, 222, 113, 27);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("\u52A0\u5165\u8D2D\u7269\u8F66");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Carthings.goods.add(a2);
			}
		});
		button_3.setBounds(327, 222, 113, 27);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("\u52A0\u5165\u8D2D\u7269\u8F66");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Carthings.goods.add(a3);
			}
		});
		button_4.setBounds(480, 222, 113, 27);
		contentPane.add(button_4);
		
	}
}
