import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class login extends JFrame {

	private JPanel contentPane;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	ArrayList userlist=new ArrayList();
	User user =new User();
	Store store=new Store();
	Connection conn=null;
	Statement pstm;
	ResultSet rs = null;
	String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	
	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public login() throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/javademo?"+ "user=root&password=123456&useUnicode=true&characterEncoding=UTF8";
		conn = DriverManager.getConnection(url);
		pstm = conn.createStatement();
		String sql="select * from user";
		rs = pstm.executeQuery(sql);  
		setTitle("\u767B\u9646");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField_1 = new JTextField();
		textField_1.setText("\u7528\u6237\u540D");
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setColumns(10);
		textField_1.setBounds(10, 79, 86, 24);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(113, 74, 292, 34);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setText("\u5BC6\u7801");
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setColumns(10);
		textField_3.setBounds(10, 123, 86, 24);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(113, 116, 292, 39);
		contentPane.add(textField_4);
		
		JButton button = new JButton("\u767B\u9646");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int n=0;n<20;n++){
					try {
						while(rs.next()){
							user.name = rs.getString(n+1);
							user.password = rs.getString(n+2);
							userlist.add(user);
							String a =textField_2.getText();
							String b =textField_4.getText();
							if(user.name.equals(a)&&user.password.equals(b)){
								store.setVisible(true);
								dispose();
							}
							else{
								textField_5.setText("������������ԣ���������ȷ��Ȼ���ܽ��룬������ע�ᡱ�ٷ���");
							}
						}
					} catch (SQLException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
				}
			}
		});
		button.setBounds(10, 178, 281, 27);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u6CE8\u518C");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				regists regists;
				try {
					regists = new regists();
					regists.setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		});
		button_1.setBounds(305, 178, 97, 27);
		contentPane.add(button_1);
		
		textField_5 = new JTextField();
		textField_5.setBounds(10, 218, 395, 24);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
	}

}
