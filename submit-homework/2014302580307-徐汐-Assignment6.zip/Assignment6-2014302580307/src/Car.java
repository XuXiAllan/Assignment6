import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Car extends JFrame {

	private JPanel contentPane;
	String all="";
	/**
	 * Create the frame.
	 */
	public Car() {
		setTitle("\u8D2D\u7269\u8F66");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 381);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(59, 85, 202, 105);
		contentPane.add(textArea);
		for(int n=0;n<Carthings.goods.size();n++){
			String a =(String) Carthings.goods.get(n)+"\r\n";
			all+=a;
		}
		textArea.setText(all);
		
		JButton button = new JButton("\u7ACB\u5373\u8D2D\u4E70");
		button.setBounds(327, 121, 113, 27);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u540E\u9000");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Store store;
				try {
					store = new Store();
					store.setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
				dispose();
			}
		});
		button_1.setBounds(0, 0, 113, 27);
		contentPane.add(button_1);
		
		
	}
}
