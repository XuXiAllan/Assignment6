import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class regists extends JFrame {

	private JPanel contentPane;
	Connection conn=null;
	Statement pstm;
	ResultSet rs = null;
	String url = "jdbc:mysql://localhost:3306/javademo?"+ "user=root&password=123456&useUnicode=true&characterEncoding=UTF8";
	private JTextField textField;

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public regists() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		login login=new login();
		setTitle("\u6CE8\u518C");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextField textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setText("\u7528\u6237\u540D");
		textField_1.setColumns(10);
		textField_1.setBounds(10, 37, 86, 24);
		getContentPane().add(textField_1);
		
		JTextField textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(113, 32, 292, 34);
		getContentPane().add(textField_2);
		
		JTextField textField_3 = new JTextField();
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setText("\u5BC6\u7801");
		textField_3.setColumns(10);
		textField_3.setBounds(10, 86, 86, 24);
		getContentPane().add(textField_3);
		
		JTextField textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(113, 79, 292, 39);
		getContentPane().add(textField_4);
		
		JTextField textField_5 = new JTextField();
		textField_5.setHorizontalAlignment(SwingConstants.CENTER);
		textField_5.setText("\u786E\u8BA4\u5BC6\u7801");
		textField_5.setColumns(10);
		textField_5.setBounds(10, 136, 86, 24);
		getContentPane().add(textField_5);
		
		JTextField textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(113, 131, 292, 39);
		getContentPane().add(textField_6);
		
		JButton button = new JButton("\u6CE8\u518C");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					conn = DriverManager.getConnection(url);
				} catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				try {
					pstm = conn.createStatement();
				} catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				String sql="select * from user";
				try {
					rs = pstm.executeQuery(sql);
				} catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				if(textField_4.getText().equals(textField_6.getText())){
					String name = textField_2.getText();
					String password = textField_4.getText();
					sql = "insert into user(name,password) values('"+name+"','"+password+"')";
					try {
						pstm.executeUpdate(sql);
					} catch (SQLException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
					login.setVisible(true);
					dispose();
				}
				else{
					textField.setText("�������벻һ�£���ȷ����������");
				}
			}
		});
		button.setBounds(30, 183, 375, 34);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u540E\u9000");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login login;
				try {
					login = new login();
					login.setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
				dispose();
			}
		});
		button_1.setBounds(0, 0, 63, 27);
		contentPane.add(button_1);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(30, 223, 375, 30);
		contentPane.add(textField);
	}
}
