
public class Pet {
	int id;
	String name;
	String drink;
	String eat;
	String live;
	String hobby;
}
