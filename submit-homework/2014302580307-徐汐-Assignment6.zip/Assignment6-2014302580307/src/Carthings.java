import java.util.ArrayList;

public class Carthings {
	static ArrayList goods=new ArrayList();
}
